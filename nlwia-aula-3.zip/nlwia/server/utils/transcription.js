export const transcriptionExample = `
O JavaScript é uma linguagem de programação voltada para o desenvolvimento web, 
criada originalmente para funcionar do lado do usuário, ou seja, nos navegadores. 
Junto do HTML e do CSS, é uma das principais tecnologias da web permitindo 
a criação de páginas interativas com elementos dinâmicos.
`